use axum::{
    extract::Path,
    response::Html,
    routing::get,
    Router,
    serve,
};
use serde::Serialize;
use std::net::SocketAddr;
use tokio::net::TcpListener;
use tower_http::services::ServeDir;

#[derive(Clone, Serialize)]
struct Evento {
    id: u32,
    nome: &'static str,
    data: &'static str,
    local: &'static str,
    preco: f32,
}

#[derive(Clone, Serialize)]
struct Artista {
    slug: &'static str,
    nome: &'static str,
    genero: &'static str,   // "trap" | "funk" | "rap"
    origem: &'static str,   // "nacional" | "internacional"
    descricao: &'static str,
    imagem: &'static str,   // caminho em /static/img/...
}

fn eventos() -> Vec<Evento> {
    vec![
        Evento {
            id: 1,
            nome: "Tech Week 2025 - One More Show",
            data: "21/11/2025",
            local: "Arena Digital • Online",
            preco: 49.90,
        },
    ]
}

fn artistas() -> Vec<Artista> {
    vec![
        // Trap nacional
        Artista {
            slug: "matue",
            nome: "Matuê",
            genero: "trap",
            origem: "nacional",
            descricao: "Um dos maiores nomes do trap nacional, referência em melodias e grandes hits.",
            imagem: "/static/img/matue.jpg",
        },
        Artista {
            slug: "teto",
            nome: "Teto",
            genero: "trap",
            origem: "nacional",
            descricao: "Novo nome do trap brasileiro, dono de flows marcantes e hits virais.",
            imagem: "/static/img/teto.jpg",
        },
        Artista {
            slug: "wiu",
            nome: "WIU",
            genero: "trap",
            origem: "nacional",
            descricao: "Produtor e artista que mistura trap com referências pop e eletrônicas.",
            imagem: "/static/img/wiu.jpg",
        },
        // Trap internacional
        Artista {
            slug: "travis-scott",
            nome: "Travis Scott",
            genero: "trap",
            origem: "internacional",
            descricao: "Um dos maiores nomes do trap mundial, conhecido por shows imersivos.",
            imagem: "/static/img/travis_scott.jpg",
        },
        Artista {
            slug: "playboi-carti",
            nome: "Playboi Carti",
            genero: "trap",
            origem: "internacional",
            descricao: "Ícone do trap moderno, com estética única e som experimental.",
            imagem: "/static/img/playboi_carti.jpg",
        },
        Artista {
            slug: "yeat",
            nome: "Yeat",
            genero: "trap",
            origem: "internacional",
            descricao: "Trap futurista com graves pesados e estética cyber.",
            imagem: "/static/img/yeat.jpg",
        },
        // Funk nacional
        Artista {
            slug: "anitta",
            nome: "Anitta",
            genero: "funk",
            origem: "nacional",
            descricao: "Do baile para o mundo, mistura funk com pop e referências globais.",
            imagem: "/static/img/anitta.jpg",
        },
        Artista {
            slug: "kevin-o-chris",
            nome: "Kevin O Chris",
            genero: "funk",
            origem: "nacional",
            descricao: "Referência do funk 150 BPM, dono de hits que dominam as pistas.",
            imagem: "/static/img/kevin_o_chris.jpg",
        },
        Artista {
            slug: "mc-poze",
            nome: "MC Poze do Rodo",
            genero: "funk",
            origem: "nacional",
            descricao: "Um dos maiores nomes do funk carioca, voz forte das comunidades.",
            imagem: "/static/img/mc_poze.jpg",
        },
        // Funk internacional / urbano
        Artista {
            slug: "rosalia",
            nome: "ROSALÍA",
            genero: "funk",
            origem: "internacional",
            descricao: "Artista espanhola que mistura urbano, reggaeton e experimental.",
            imagem: "/static/img/rosalia.jpg",
        },
        Artista {
            slug: "bad-bunny",
            nome: "Bad Bunny",
            genero: "funk",
            origem: "internacional",
            descricao: "Um dos maiores nomes da música latina e urbana no mundo.",
            imagem: "/static/img/bad_bunny.jpg",
        },
        Artista {
            slug: "karol-g",
            nome: "Karol G",
            genero: "funk",
            origem: "internacional",
            descricao: "Pop urbano e reggaeton, dona de hits globais e grandes feats.",
            imagem: "/static/img/karol_g.jpg",
        },
        // Rap nacional
        Artista {
            slug: "djonga",
            nome: "Djonga",
            genero: "rap",
            origem: "nacional",
            descricao: "Letras fortes, crítica social e um dos maiores nomes do rap BR.",
            imagem: "/static/img/djonga.jpg",
        },
        Artista {
            slug: "bk",
            nome: "BK'",
            genero: "rap",
            origem: "nacional",
            descricao: "Rap introspectivo, visual forte e discos aclamados pela crítica.",
            imagem: "/static/img/bk.jpg",
        },
        Artista {
            slug: "racionais",
            nome: "Racionais MC's",
            genero: "rap",
            origem: "nacional",
            descricao: "Lenda máxima do rap brasileiro, base de toda uma geração.",
            imagem: "/static/img/racionais.jpg",
        },
        // Rap internacional
        Artista {
            slug: "kendrick-lamar",
            nome: "Kendrick Lamar",
            genero: "rap",
            origem: "internacional",
            descricao: "Um dos maiores letristas da história, vencedor de múltiplos Grammys.",
            imagem: "/static/img/kendrick_lamar.jpg",
        },
        Artista {
            slug: "drake",
            nome: "Drake",
            genero: "rap",
            origem: "internacional",
            descricao: "Rapper e hitmaker global, transitando entre rap, R&B e pop.",
            imagem: "/static/img/drake.jpg",
        },
        Artista {
            slug: "eminem",
            nome: "Eminem",
            genero: "rap",
            origem: "internacional",
            descricao: "Um dos rappers mais influentes de todos os tempos.",
            imagem: "/static/img/eminem.jpg",
        },
    ]
}

fn base_css() -> &'static str {
    r#"
    :root {
        color-scheme: dark;
        --purple-500: #6C3BFF;
        --purple-400: #8E4CFF;
        --purple-300: #B686FF;
        --purple-200: #D8C0FF;
        --blue-neon: #5B46E8;
        --magenta: #FF00D4;
        --bg-main: #050014;
        --bg-card: #12002E;
        --bg-soft: #1B1038;
        --text-main: #F9FAFB;
        --text-muted: #9CA3AF;
        --border-soft: rgba(148, 163, 184, 0.35);
    }

    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        padding: 0;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        background:
            radial-gradient(circle at top left, rgba(108,59,255,0.45), transparent 55%),
            radial-gradient(circle at top right, rgba(255,0,212,0.28), transparent 60%),
            radial-gradient(circle at bottom, rgba(24,24,27,0.9), #050014 70%);
        color: var(--text-main);
        min-height: 100vh;
    }

    a {
        color: inherit;
        text-decoration: none;
    }

    .shell {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px 16px 48px;
    }

    .nav {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 14px 18px;
        border-radius: 999px;
        border: 1px solid var(--border-soft);
        background: radial-gradient(circle at top left, rgba(255,255,255,0.08), rgba(15,23,42,0.92));
        backdrop-filter: blur(18px);
        position: sticky;
        top: 16px;
        z-index: 20;
    }

    .logo-mark {
        display: flex;
        flex-direction: column;
        gap: 2px;
    }

    .logo-small {
        font-size: 0.65rem;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: var(--purple-200);
    }

    .logo-main {
        font-weight: 800;
        font-size: 0.9rem;
        letter-spacing: 0.22em;
    }

    .nav-links {
        display: flex;
        gap: 12px;
        align-items: center;
        font-size: 0.8rem;
    }

    .pill-nav {
        padding: 6px 12px;
        border-radius: 999px;
        border: 1px solid var(--border-soft);
        display: inline-flex;
        align-items: center;
        gap: 6px;
        color: var(--text-muted);
    }

    .pill-nav span.dot {
        width: 6px;
        height: 6px;
        border-radius: 999px;
        background: #22c55e;
        box-shadow: 0 0 10px rgba(34,197,94,0.9);
    }

    .nav a.link {
        padding: 6px 10px;
        border-radius: 999px;
        color: var(--text-muted);
    }

    .nav a.link.active {
        background: rgba(108,59,255,0.25);
        color: var(--text-main);
    }

    .hero {
        margin-top: 36px;
        display: grid;
        grid-template-columns: minmax(0, 2.1fr) minmax(0, 1.4fr);
        gap: 26px;
        align-items: center;
    }

    .hero-card {
        border-radius: 26px;
        padding: 22px 22px 24px;
        background:
            radial-gradient(circle at top left, rgba(255,255,255,0.22), transparent 60%),
            linear-gradient(135deg, #1B1038, #050014);
        border: 1px solid rgba(216,192,255,0.25);
        box-shadow: 0 26px 80px rgba(15,23,42,0.9);
        position: relative;
        overflow: hidden;
    }

    .hero-kicker {
        font-size: 0.7rem;
        letter-spacing: 0.2em;
        text-transform: uppercase;
        color: var(--purple-200);
        margin-bottom: 8px;
    }

    .hero-title {
        font-size: clamp(2.2rem, 3.6vw, 2.9rem);
        line-height: 1.05;
        font-weight: 800;
        margin: 0 0 8px;
    }

    .hero-sub {
        font-size: 0.9rem;
        color: var(--text-muted);
        max-width: 360px;
    }

    .hero-meta {
        margin-top: 18px;
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        font-size: 0.8rem;
        color: var(--text-muted);
    }

    .hero-meta span.badge {
        padding: 4px 9px;
        border-radius: 999px;
        border: 1px solid rgba(148,163,184,0.5);
        background: rgba(15,23,42,0.9);
    }

    .hero-cta-row {
        margin-top: 22px;
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
    }

    .btn-primary {
        padding: 10px 20px;
        border-radius: 999px;
        border: none;
        background: linear-gradient(135deg, var(--purple-500), var(--magenta));
        color: #020617;
        font-weight: 700;
        font-size: 0.9rem;
        cursor: pointer;
        box-shadow: 0 16px 40px rgba(58,12,163,0.9);
    }

    .btn-primary:hover {
        filter: brightness(1.05);
    }

    .btn-ghost {
        padding: 8px 14px;
        border-radius: 999px;
        border: 1px solid rgba(148,163,184,0.5);
        background: transparent;
        color: var(--text-muted);
        font-size: 0.8rem;
        cursor: pointer;
    }

    .hero-right {
        border-radius: 24px;
        padding: 18px 18px 20px;
        background: radial-gradient(circle at top, rgba(255,255,255,0.1), transparent 65%);
        border: 1px solid var(--border-soft);
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .hero-right-header {
        font-size: 0.85rem;
        color: var(--text-muted);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .hero-right-main {
        margin-top: 6px;
        padding: 10px;
        border-radius: 18px;
        background: rgba(5,5,12,0.85);
        display: flex;
        flex-direction: column;
        gap: 8px;
        font-size: 0.82rem;
    }

    .hero-right-main strong {
        color: var(--purple-200);
    }

    .hero-right-footer {
        font-size: 0.75rem;
        color: var(--text-muted);
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 4px;
    }

    .chip-row {
        margin-top: 10px;
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        font-size: 0.75rem;
    }

    .chip {
        padding: 4px 9px;
        border-radius: 999px;
        border: 1px solid rgba(148,163,184,0.5);
        background: rgba(15,23,42,0.88);
    }

    .section {
        margin-top: 40px;
    }

    .section-header {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        margin-bottom: 16px;
    }

    .section-title {
        font-size: 1.05rem;
        font-weight: 600;
    }

    .section-sub {
        font-size: 0.8rem;
        color: var(--text-muted);
    }

    .pill-tabs {
        display: inline-flex;
        gap: 4px;
        border-radius: 999px;
        padding: 3px;
        background: rgba(15,23,42,0.9);
        border: 1px solid rgba(148,163,184,0.4);
    }

    .pill-tab {
        padding: 4px 10px;
        border-radius: 999px;
        font-size: 0.75rem;
        color: var(--text-muted);
    }

    .pill-tab.active {
        background: linear-gradient(135deg, var(--purple-500), var(--magenta));
        color: #020617;
        font-weight: 600;
    }

    .artist-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 14px;
    }

    .artist-card {
        border-radius: 20px;
        padding: 10px 10px 12px;
        background: radial-gradient(circle at top, rgba(108,59,255,0.25), rgba(5,0,20,0.96));
        border: 1px solid rgba(148,163,184,0.35);
        box-shadow: 0 18px 40px rgba(15,23,42,0.9);
        cursor: pointer;
        transition: transform 120ms ease, box-shadow 120ms ease;
    }

    .artist-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 24px 60px rgba(0,0,0,0.95);
    }

    .artist-thumb {
        width: 100%;
        aspect-ratio: 4 / 3;
        border-radius: 16px;
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
        margin-bottom: 8px;
    }

    .artist-name {
        font-size: 0.9rem;
        font-weight: 600;
    }

    .artist-tagline {
        font-size: 0.75rem;
        color: var(--text-muted);
    }

    .pill-origin {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 0.7rem;
        padding: 2px 7px;
        border-radius: 999px;
        border: 1px solid rgba(148,163,184,0.5);
        margin-top: 4px;
        color: var(--text-muted);
    }

    .pill-origin span.dot-small {
        width: 5px;
        height: 5px;
        border-radius: 999px;
        background: var(--magenta);
    }

    .footer {
        margin-top: 40px;
        padding-top: 18px;
        border-top: 1px solid rgba(31,41,55,0.7);
        font-size: 0.75rem;
        color: var(--text-muted);
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 8px;
    }

    @media (max-width: 780px) {
        .hero {
            grid-template-columns: minmax(0, 1fr);
        }
        .nav {
            flex-direction: column;
            gap: 10px;
            align-items: flex-start;
        }
    }

    /* Página de gênero */

    .genre-layout {
        margin-top: 30px;
        display: grid;
        grid-template-columns: minmax(0, 2.1fr) minmax(0, 1.3fr);
        gap: 24px;
        align-items: flex-start;
    }

    .genre-sidebar {
        border-radius: 22px;
        padding: 16px 16px 18px;
        background: radial-gradient(circle at top, rgba(255,255,255,0.12), rgba(5,0,20,0.96));
        border: 1px solid var(--border-soft);
        font-size: 0.82rem;
        color: var(--text-muted);
    }

    .genre-sidebar h2 {
        margin: 0 0 6px;
        font-size: 1rem;
    }

    .genre-sidebar ul {
        padding-left: 16px;
        margin: 8px 0 0;
    }

    .genre-sidebar li {
        margin-bottom: 4px;
    }

    /* Página de artista */

    .artist-layout {
        margin-top: 32px;
        display: grid;
        grid-template-columns: minmax(0, 1.6fr) minmax(0, 1.6fr);
        gap: 22px;
        align-items: center;
    }

    .artist-cover {
        border-radius: 26px;
        padding: 14px;
        border: 1px solid rgba(148,163,184,0.4);
        background:
            radial-gradient(circle at top, rgba(255,255,255,0.16), transparent 65%),
            linear-gradient(145deg, #050014, #1B1038);
        box-shadow: 0 26px 80px rgba(15,23,42,0.95);
    }

    .artist-cover-inner {
        border-radius: 20px;
        overflow: hidden;
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
        aspect-ratio: 4 / 3;
    }

    .artist-info h1 {
        font-size: 1.8rem;
        margin: 0 0 6px;
    }

    .artist-info p {
        font-size: 0.88rem;
        color: var(--text-muted);
    }

    .artist-meta-row {
        margin-top: 10px;
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        font-size: 0.78rem;
    }

    .badge-soft {
        padding: 4px 9px;
        border-radius: 999px;
        border: 1px solid rgba(148,163,184,0.5);
    }

    .qr-box {
        margin-top: 18px;
        border-radius: 18px;
        padding: 14px;
        border: 1px dashed rgba(148,163,184,0.5);
        font-size: 0.8rem;
        color: var(--text-muted);
    }
    "#
}

fn layout(title: &str, body: String, active: &str) -> Html<String> {
    let css = base_css();
    let nav_home = if active == "home" { "link active" } else { "link" };
    let nav_trap = if active == "trap" { "link active" } else { "link" };
    let nav_funk = if active == "funk" { "link active" } else { "link" };
    let nav_rap = if active == "rap" { "link active" } else { "link" };

    Html(format!(
        r#"<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8" />
    <title>{title}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>{css}</style>
</head>
<body>
    <div class="shell">
        <nav class="nav">
            <div class="logo-mark">
                <span class="logo-small">ONE MORE</span>
                <span class="logo-main">SHOW</span>
            </div>
            <div class="nav-links">
                <div class="pill-nav">
                    <span class="dot"></span>
                    <span>Evento digital • Tech Week</span>
                </div>
                <a href="/" class="{nav_home}">Início</a>
                <a href="/genero/trap" class="{nav_trap}">Trap</a>
                <a href="/genero/funk" class="{nav_funk}">Funk</a>
                <a href="/genero/rap" class="{nav_rap}">Rap</a>
            </div>
        </nav>
        {body}
        <footer class="footer">
            <span>ONE MORE SHOW • Projeto conceitual inspirado na sua Tech Week.</span>
            <span>Design baseado no layout do Figma • Paleta roxo neon.</span>
        </footer>
    </div>
</body>
</html>
"#,
        title = title,
        css = css,
        nav_home = nav_home,
        nav_trap = nav_trap,
        nav_funk = nav_funk,
        nav_rap = nav_rap,
        body = body,
    ))
}

#[tokio::main]
async fn main() {
    let app = Router::new()
        .route("/", get(home))
        .route("/genero/:slug", get(pagina_genero))
        .route("/artista/:slug", get(pagina_artista))
        .nest_service("/static", ServeDir::new("static"));

    let addr = SocketAddr::from(([127, 0, 0, 1], 3000));
    println!("Servidor rodando em http://{addr}");

    let listener = TcpListener::bind(addr).await.unwrap();
    serve(listener, app.into_make_service())
        .await
        .unwrap();
}

async fn home() -> Html<String> {
    let evs = eventos();
    let arts = artistas();

    let evento = &evs[0];

    let mut destaques_trap = String::new();
    for a in arts.iter().filter(|a| a.genero == "trap").take(4) {
        destaques_trap.push_str(&artist_card(a));
    }

    let mut destaques_funk = String::new();
    for a in arts.iter().filter(|a| a.genero == "funk").take(4) {
        destaques_funk.push_str(&artist_card(a));
    }

    let mut destaques_rap = String::new();
    for a in arts.iter().filter(|a| a.genero == "rap").take(4) {
        destaques_rap.push_str(&artist_card(a));
    }

    let body = format!(
        r#"
<section class="hero">
    <div class="hero-card">
        <div class="hero-kicker">ONE MORE SHOW • TECH WEEK</div>
        <h1 class="hero-title">Um festival para maratonar seus artistas favoritos.</h1>
        <p class="hero-sub">
            Trap, funk e rap em um palco digital. Escolha o gênero, monte sua própria line-up
            e garanta o seu ingresso para a One More Show.
        </p>
        <div class="hero-meta">
            <span class="badge">{data}</span>
            <span class="badge">{local}</span>
            <span class="badge">Acesso online • Full HD</span>
        </div>
        <div class="hero-cta-row">
            <a href="/genero/trap">
                <button class="btn-primary">Explorar artistas</button>
            </a>
            <button class="btn-ghost">Ver programação completa</button>
        </div>
        <div class="chip-row">
            <div class="chip">Trap nacional &amp; internacional</div>
            <div class="chip">Funk BR &amp; urbano global</div>
            <div class="chip">Rap de todas as gerações</div>
        </div>
    </div>
    <aside class="hero-right">
        <div class="hero-right-header">
            <span>Ingresso digital Tech Week</span>
            <span style="font-size:0.75rem;color:var(--purple-200);">Lote atual</span>
        </div>
        <div class="hero-right-main">
            <div><strong>{nome_evento}</strong></div>
            <div>Data: {data}</div>
            <div>Local: {local}</div>
            <div>Formato: Online • Multi-câmera</div>
            <div>Ingresso a partir de <strong>R$ {preco:.2}</strong></div>
        </div>
        <div class="hero-right-footer">
            <span>Pagamento seguro via PIX / cartão.</span>
            <span style="font-size:0.7rem;">Design inspirado no layout do Figma.</span>
        </div>
    </aside>
</section>

<section class="section">
    <div class="section-header">
        <div>
            <div class="section-title">Trap • Nacionais &amp; internacionais</div>
            <div class="section-sub">O ritmo que domina a geração digital.</div>
        </div>
        <a href="/genero/trap" class="section-sub">Ver todos &rarr;</a>
    </div>
    <div class="artist-grid">
        {destaques_trap}
    </div>
</section>

<section class="section">
    <div class="section-header">
        <div>
            <div class="section-title">Funk &amp; urbano</div>
            <div class="section-sub">Do baile ao palco global.</div>
        </div>
        <a href="/genero/funk" class="section-sub">Ver todos &rarr;</a>
    </div>
    <div class="artist-grid">
        {destaques_funk}
    </div>
</section>

<section class="section">
    <div class="section-header">
        <div>
            <div class="section-title">Rap • BR &amp; mundo</div>
            <div class="section-sub">Clássicos e novos nomes lado a lado.</div>
        </div>
        <a href="/genero/rap" class="section-sub">Ver todos &rarr;</a>
    </div>
    <div class="artist-grid">
        {destaques_rap}
    </div>
</section>
"#,
        data = evento.data,
        local = evento.local,
        nome_evento = evento.nome,
        preco = evento.preco,
        destaques_trap = destaques_trap,
        destaques_funk = destaques_funk,
        destaques_rap = destaques_rap,
    );

    layout("One More Show - Ingressos", body, "home")
}

fn artist_card(a: &Artista) -> String {
    format!(
        r#"
        <a href="/artista/{slug}">
            <article class="artist-card">
                <div class="artist-thumb" style="background-image:url('{img}');"></div>
                <div class="artist-name">{nome}</div>
                <div class="artist-tagline">{genero}</div>
                <div class="pill-origin">
                    <span class="dot-small"></span>
                    <span>{origem}</span>
                </div>
            </article>
        </a>
    "#,
        slug = a.slug,
        img = a.imagem,
        nome = a.nome,
        genero = match a.genero {
            "trap" => "Trap",
            "funk" => "Funk / Urbano",
            "rap" => "Rap",
            _ => "",
        },
        origem = match a.origem {
            "nacional" => "Brasil",
            "internacional" => "Internacional",
            _ => a.origem,
        },
    )
}

async fn pagina_genero(Path(slug): Path<String>) -> Html<String> {
    let genero = slug.to_lowercase();
    let all = artistas();
    let filtrados: Vec<Artista> = all
        .into_iter()
        .filter(|a| a.genero == genero)
        .collect();

    let (titulo, sub) = match genero.as_str() {
        "trap" => ("Trap", "808 batendo, melodias melódicas e flows em alta velocidade."),
        "funk" => ("Funk & Urbano", "Baile, dança e som que domina as pistas."),
        "rap" => ("Rap", "Letras, rimas e histórias que marcam gerações."),
        _ => ("Gênero", "Curadoria de artistas."),
    };

    let mut grid_nacional = String::new();
    let mut grid_internacional = String::new();

    for a in filtrados.iter() {
        if a.origem == "nacional" {
            grid_nacional.push_str(&artist_card(a));
        } else {
            grid_internacional.push_str(&artist_card(a));
        }
    }

    let body = format!(
        r#"
<section class="section">
    <div class="section-header">
        <div>
            <div class="section-title">{titulo}</div>
            <div class="section-sub">{sub}</div>
        </div>
        <div class="pill-tabs">
            <span class="pill-tab active">{titulo}</span>
            <span class="pill-tab">Biblioteca</span>
        </div>
    </div>
    <div class="genre-layout">
        <div>
            <h3 style="font-size:0.85rem;margin:0 0 8px;">Nacionais</h3>
            <div class="artist-grid" style="margin-bottom:18px;">
                {grid_nacional}
            </div>
            <h3 style="font-size:0.85rem;margin:16px 0 8px;">Internacionais</h3>
            <div class="artist-grid">
                {grid_internacional}
            </div>
        </div>
        <aside class="genre-sidebar">
            <h2>Curadoria One More Show</h2>
            <p>
                Esta tela imita a experiência do seu Figma: um painel lateral explicando o gênero,
                como funciona a line-up e como o público navega entre os estilos.
            </p>
            <ul>
                <li>Selecione um gênero no topo (Trap, Funk, Rap);</li>
                <li>Clique em um artista para abrir a página detalhada;</li>
                <li>Use esta biblioteca como base para as próximas versões.</li>
            </ul>
        </aside>
    </div>
</section>
"#,
        titulo = titulo,
        sub = sub,
        grid_nacional = grid_nacional,
        grid_internacional = grid_internacional,
    );

    let active = genero.as_str();
    layout(&format!("{titulo} • One More Show"), body, active)
}

async fn pagina_artista(Path(slug): Path<String>) -> Html<String> {
    let all = artistas();
    if let Some(a) = all.into_iter().find(|x| x.slug == slug) {
        let body = format!(
            r#"
<section class="section artist-layout">
    <div class="artist-cover">
        <div class="artist-cover-inner" style="background-image:url('{img}');"></div>
    </div>
    <div class="artist-info">
        <h1>{nome}</h1>
        <p>{desc}</p>
        <div class="artist-meta-row">
            <span class="badge-soft">{genero}</span>
            <span class="badge-soft">{origem}</span>
            <span class="badge-soft">One More Show • Tech Week</span>
        </div>
        <div class="qr-box">
            Esta área representa aquela tela do Figma com QR Code e call-to-action.
            Aqui você pode futuramente inserir um QR real, link de playlist ou CTA do evento.
        </div>
    </div>
</section>
"#,
            img = a.imagem,
            nome = a.nome,
            desc = a.descricao,
            genero = match a.genero {
                "trap" => "Trap",
                "funk" => "Funk / Urbano",
                "rap" => "Rap",
                _ => "",
            },
            origem = match a.origem {
                "nacional" => "Brasil",
                "internacional" => "Internacional",
                _ => a.origem,
            },
        );

        let active = a.genero;
        layout(&format!("{} • One More Show", a.nome), body, active)
    } else {
        layout(
            "Artista não encontrado",
            "<section class=\"section\"><p>Artista não encontrado.</p></section>".to_string(),
            "home",
        )
    }
}